#!/bin/sh
cat ./exercise2f/exploit
tee
